/* Name :           Mohamed Asad Bandarkar
   Student Number : 4271451
   Practical 1 Question 1
 */

public class Practical11 {

    public static boolean verifyPassword(String password) {
        if (password == null || password.length() < 8) { //checking if password is empty or has less than 8 characters
            System.out.println("The password you have entered does not contain the necessary validation rules");
            return false;
        }

        boolean hasLowerCase = false;
        boolean hasUpperCase = false;
        boolean hasDigit = false;
        boolean hasSpecialCharacter = false;

        return false;

    }
}