/* Name :           Mohamed Asad Bandarkar
   Student Number : 4271451
   Practical 1 Question 2
 */

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Practical12 {
    public static void main(String[] args) throws IOException {

        try {
            File file = new File("C://Users//Asad//Desktop/Rhyme.txt");
            
            Scanner scanner = new Scanner(file);

            //adding my name and student number to the new file
            String newFile = "My name is Mohamed Asad Bandarkar.My student number is 4271451.\n";

            //iterating all the lines in the file
            while (scanner.hasNextLine()) {
                newFile = newFile.concat(scanner.nextLine() + "\n");
            }

            FileWriter fileWriter = new FileWriter("C://Users//Asad//Desktop/Rhyme2.txt");
            fileWriter.write(newFile);
            fileWriter.close();

        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
}
